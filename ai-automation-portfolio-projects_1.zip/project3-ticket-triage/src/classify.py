"""
Classifies each unprocessed ticket by category, priority, and sentiment using
a few-shot prompt to Claude. Falls back to a keyword-based mock classifier if
no ANTHROPIC_API_KEY is set, so the pipeline is fully runnable without setup.
"""
import os
import re
import json
from datetime import datetime
from db import get_unprocessed_tickets, update_with_classification

USE_LIVE_API = bool(os.environ.get("ANTHROPIC_API_KEY"))

FEW_SHOT_PROMPT = """You are a support ticket triage system. Classify tickets consistently using these examples:

Example 1: "I was charged twice for my subscription" -> category: billing, priority: P1, sentiment: negative
Example 2: "The app crashes when I upload a file, this is a critical production issue" -> category: bug, priority: P0, sentiment: negative
Example 3: "Would love a dark mode option" -> category: feature_request, priority: P3, sentiment: neutral
Example 4: "Does this integrate with Slack?" -> category: general_question, priority: P3, sentiment: neutral
Example 5: "I'm locked out of my account, whole team is blocked, urgent!" -> category: account, priority: P0, sentiment: negative

Priority scale: P0 = critical/blocking, P1 = high impact, P2 = normal, P3 = low/no rush.

Now classify this ticket: "{text}"

Respond with ONLY valid JSON, no other text:
{{"category": "billing" | "bug" | "feature_request" | "account" | "general_question",
  "priority": "P0" | "P1" | "P2" | "P3",
  "sentiment": "positive" | "negative" | "neutral"}}
"""

def classify_with_claude(text: str) -> dict:
    import anthropic
    client = anthropic.Anthropic()
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=150,
        messages=[{"role": "user", "content": FEW_SHOT_PROMPT.format(text=text)}]
    )
    raw = response.content[0].text.strip()
    raw = re.sub(r"^```json|```$", "", raw, flags=re.MULTILINE).strip()
    return json.loads(raw)

def classify_with_mock(text: str) -> dict:
    lower = text.lower()

    category_kw = {
        "billing": ["charge", "invoice", "subscription", "refund", "card", "plan", "downgrade"],
        "bug": ["crash", "wrong totals", "doesn't", "does nothing", "sync", "bug", "broken"],
        "feature_request": ["would love", "please add", "can you add", "would help", "add support"],
        "account": ["locked out", "reset email", "transfer ownership", "deleted my project", "merge two accounts"],
    }
    category = "general_question"
    for cat, kws in category_kw.items():
        if any(k in lower for k in kws):
            category = cat
            break

    urgent_kw = ["urgent", "critical", "blocked", "losing money", "frustrated"]
    is_urgent = any(k in lower for k in urgent_kw)

    if is_urgent:
        priority = "P0"
    elif category in ("billing", "bug", "account"):
        priority = "P1"
    elif category == "feature_request":
        priority = "P3"
    else:
        priority = "P2"

    negative_kw = ["crash", "declined", "locked out", "deleted", "urgent", "frustrated", "twice", "wrong"]
    sentiment = "negative" if any(k in lower for k in negative_kw) else "neutral"

    return {"category": category, "priority": priority, "sentiment": sentiment}

def run_classification_batch():
    tickets = get_unprocessed_tickets()
    if not tickets:
        print("No unprocessed tickets found.")
        return

    classifier = classify_with_claude if USE_LIVE_API else classify_with_mock
    mode = "Claude API (few-shot)" if USE_LIVE_API else "mock heuristic (set ANTHROPIC_API_KEY for live LLM)"
    print(f"Classifying {len(tickets)} tickets using {mode}...")

    for t in tickets:
        try:
            result = classifier(t["text"])
        except Exception as e:
            print(f"  ! Failed on {t['ticket_id']}: {e} — falling back to mock")
            result = classify_with_mock(t["text"])

        update_with_classification(
            ticket_id=t["ticket_id"],
            category=result["category"],
            priority=result["priority"],
            sentiment=result["sentiment"],
            processed_at=datetime.now().isoformat()
        )

    print(f"Done. Classified and routed {len(tickets)} tickets.")

if __name__ == "__main__":
    run_classification_batch()
