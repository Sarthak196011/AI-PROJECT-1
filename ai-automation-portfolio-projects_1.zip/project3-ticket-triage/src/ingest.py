import json
from pathlib import Path
from db import init_db, insert_raw_ticket

RAW_DATA_PATH = Path(__file__).parent.parent / "data" / "raw_tickets.json"

def load_from_json():
    with open(RAW_DATA_PATH) as f:
        tickets = json.load(f)
    init_db()
    for t in tickets:
        insert_raw_ticket(t)
    print(f"Ingested {len(tickets)} tickets into database.")

if __name__ == "__main__":
    load_from_json()
