import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "tickets.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS tickets (
    ticket_id TEXT PRIMARY KEY,
    text TEXT NOT NULL,
    created_at TEXT NOT NULL,
    resolved_at TEXT,
    category TEXT,
    priority TEXT,        -- P0 / P1 / P2 / P3
    sentiment TEXT,
    assigned_team TEXT,
    processed_at TEXT
);
"""

TEAM_ROUTING = {
    "billing": "Billing Ops",
    "bug": "Engineering",
    "feature_request": "Product",
    "account": "Account Support",
    "general_question": "Customer Success",
}

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    conn.execute(SCHEMA)
    conn.commit()
    conn.close()

def insert_raw_ticket(ticket: dict):
    conn = get_connection()
    conn.execute(
        "INSERT OR IGNORE INTO tickets (ticket_id, text, created_at, resolved_at) VALUES (?, ?, ?, ?)",
        (ticket["ticket_id"], ticket["text"], ticket["created_at"], ticket.get("resolved_at"))
    )
    conn.commit()
    conn.close()

def update_with_classification(ticket_id, category, priority, sentiment, processed_at):
    team = TEAM_ROUTING.get(category, "Customer Success")
    conn = get_connection()
    conn.execute(
        "UPDATE tickets SET category=?, priority=?, sentiment=?, assigned_team=?, processed_at=? WHERE ticket_id=?",
        (category, priority, sentiment, team, processed_at, ticket_id)
    )
    conn.commit()
    conn.close()

def get_unprocessed_tickets():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM tickets WHERE category IS NULL").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_all_tickets():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM tickets ORDER BY created_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]
