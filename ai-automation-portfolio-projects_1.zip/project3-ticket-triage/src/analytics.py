"""
Ops analytics: resolution times by category, SLA compliance, team load,
and an automated alert if P0 volume in the last hour exceeds a threshold.
"""
import os
from datetime import datetime, timedelta
from db import get_all_tickets

P0_SPIKE_THRESHOLD = 3          # alert if >= this many P0 tickets in the window
P0_SPIKE_WINDOW_HOURS = 1

SLA_TARGETS_HOURS = {"P0": 4, "P1": 24, "P2": 72, "P3": 168}

def compute_resolution_hours(ticket):
    if not ticket.get("resolved_at"):
        return None
    created = datetime.fromisoformat(ticket["created_at"])
    resolved = datetime.fromisoformat(ticket["resolved_at"])
    return (resolved - created).total_seconds() / 3600

def sla_compliance_report():
    tickets = get_all_tickets()
    report = {}
    for priority, target in SLA_TARGETS_HOURS.items():
        subset = [t for t in tickets if t["priority"] == priority and t.get("resolved_at")]
        if not subset:
            report[priority] = {"count": 0, "compliance_pct": None}
            continue
        met = sum(1 for t in subset if compute_resolution_hours(t) <= target)
        report[priority] = {"count": len(subset), "compliance_pct": met / len(subset)}
    return report

def check_p0_spike():
    tickets = get_all_tickets()
    now = datetime.now()
    recent_p0 = [
        t for t in tickets
        if t["priority"] == "P0" and datetime.fromisoformat(t["created_at"]) > now - timedelta(hours=P0_SPIKE_WINDOW_HOURS)
    ]
    if len(recent_p0) >= P0_SPIKE_THRESHOLD:
        message = f":rotating_light: {len(recent_p0)} P0 tickets created in the last {P0_SPIKE_WINDOW_HOURS}h — possible incident."
        send_alert(message)
        return True
    return False

def send_alert(message: str):
    webhook = os.environ.get("SLACK_WEBHOOK_URL")
    if webhook:
        import requests
        requests.post(webhook, json={"text": message})
        print("Alert sent to Slack.")
    else:
        print("[MOCK ALERT — set SLACK_WEBHOOK_URL to send for real]")
        print(message)

if __name__ == "__main__":
    print("SLA Compliance Report:")
    for priority, stats in sla_compliance_report().items():
        pct = f"{stats['compliance_pct']:.1%}" if stats["compliance_pct"] is not None else "N/A"
        print(f"  {priority}: {stats['count']} resolved tickets, {pct} within SLA target")
    print()
    check_p0_spike()
