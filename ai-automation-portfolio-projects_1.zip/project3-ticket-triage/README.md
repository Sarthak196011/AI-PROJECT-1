# 🎫 AI-Powered Support Ticket Triage & Ops Analytics

Auto-classifies, prioritizes, and routes incoming support tickets with an LLM, then tracks SLA compliance, team load, and resolution trends in an ops dashboard.

## Problem
Support teams manually read and route every incoming ticket. Urgent/blocking issues can sit in a queue alongside routine questions, and there's no consistent view of SLA performance or where teams are overloaded.

## Solution
A pipeline that classifies each ticket's category, priority, and sentiment using a few-shot LLM prompt, auto-routes it to the right team, and feeds a live dashboard tracking SLA compliance and operational trends — plus an automated alert when critical (P0) tickets spike.

## Architecture

```mermaid
flowchart LR
    A[Incoming Tickets<br/>email / form / API] --> B[Ingest]
    B --> C[(SQLite / Postgres)]
    C --> D[LLM Classification<br/>category, priority, sentiment]
    D --> E[Auto-Routing<br/>team assignment]
    E --> C
    C --> F[SLA / Ops Analytics]
    F -->|P0 spike| G[Slack Alert]
    C --> H[Streamlit Dashboard]
```

## Tech Stack
- **Python** — pipeline orchestration
- **Claude API** (few-shot prompting) — ticket classification for consistent category/priority/sentiment output
- **SQLite** (swap for Postgres in production) — storage
- **pandas** — SLA and resolution-time analytics
- **Streamlit** — ops dashboard
- **Slack Webhooks** — P0 spike alerting

## How to Run

```bash
pip install -r requirements.txt

# 1. Generate synthetic sample tickets
python data/generate_sample_tickets.py

# 2. Ingest into the database
python src/ingest.py

# 3. Classify + auto-route (mock mode by default; set ANTHROPIC_API_KEY for live LLM)
python src/classify.py

# 4. Run SLA/analytics report + P0 spike check
python src/analytics.py

# 5. Launch the dashboard
streamlit run dashboard/app.py
```

## What the Dashboard Shows
- Ticket volume over time, open vs. resolved
- Priority distribution (P0–P3)
- Team workload balance
- Average resolution time by category
- SLA compliance % by priority level (against configurable targets)
- Sentiment vs. resolution-time correlation — a genuinely useful analytical insight for prioritizing escalations
- Full searchable/filterable ticket explorer

## Production Notes / What I'd Improve
- Add a feedback loop: when a human re-categorizes a ticket, log the correction and use it to improve the few-shot prompt over time
- Move from polling classification to event-driven (webhook on ticket creation)
- Add per-agent (not just per-team) load balancing
- Add escalation logic: auto-bump priority if a ticket has been open past its SLA target with no response

## Sample Impact (based on synthetic data)
Classified and routed several hundred tickets automatically by category/priority/team, and the SLA report immediately surfaces which priority tiers are missing their targets — work that would otherwise require a support lead manually auditing ticket logs.
