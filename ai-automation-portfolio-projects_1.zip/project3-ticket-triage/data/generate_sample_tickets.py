"""Generates synthetic support tickets with realistic category/priority/sentiment distribution."""
import json
import random
from datetime import datetime, timedelta
from pathlib import Path

TICKET_TEMPLATES = {
    "billing": [
        "I was charged twice for my subscription this month, please refund one charge.",
        "Can you explain the extra fee on my last invoice?",
        "I want to downgrade my plan but can't find the option.",
        "My card was declined but you still charged me somehow.",
    ],
    "bug": [
        "The app crashes every time I try to upload a file.",
        "Dashboard shows the wrong totals after the latest update.",
        "Login button does nothing when clicked on Safari.",
        "Data isn't syncing between my devices anymore.",
    ],
    "feature_request": [
        "Would love a dark mode option in settings.",
        "Can you add bulk export to CSV?",
        "Please add support for two-factor authentication.",
        "It would help to have keyboard shortcuts for navigation.",
    ],
    "account": [
        "I'm locked out of my account and the reset email never arrives.",
        "How do I transfer ownership of my workspace to a coworker?",
        "I accidentally deleted my project, can it be restored?",
        "Need to merge two accounts into one.",
    ],
    "general_question": [
        "Does this integrate with Slack?",
        "What's the difference between the Pro and Team plans?",
        "Is there an API I can use for automation?",
        "Do you offer a student discount?",
    ],
}

URGENT_PHRASES = [
    "This is urgent, my whole team is blocked.",
    "We're losing money every hour this is down.",
    "This is a critical production issue.",
    "Second time this week, getting really frustrated.",
]

def generate_tickets(n=400, seed=11):
    random.seed(seed)
    tickets = []
    start = datetime.now() - timedelta(days=30)

    for i in range(n):
        category = random.choice(list(TICKET_TEMPLATES.keys()))
        text = random.choice(TICKET_TEMPLATES[category])

        is_urgent = random.random() < 0.15
        if is_urgent:
            text += " " + random.choice(URGENT_PHRASES)

        created = start + timedelta(
            days=random.randint(0, 30),
            hours=random.randint(0, 23),
            minutes=random.randint(0, 59)
        )

        # simulate resolution time varying by category/urgency
        base_hours = {"bug": 18, "billing": 8, "account": 6, "feature_request": 72, "general_question": 4}
        resolve_hours = max(0.5, random.gauss(base_hours[category] / (2 if is_urgent else 1), base_hours[category] * 0.3))
        resolved = created + timedelta(hours=resolve_hours)

        tickets.append({
            "ticket_id": f"TKT-{3000+i}",
            "text": text,
            "created_at": created.isoformat(),
            "resolved_at": resolved.isoformat() if random.random() < 0.85 else None,  # 15% still open
            "_true_category_for_eval": category,
            "_true_urgent_for_eval": is_urgent,
        })

    return tickets

if __name__ == "__main__":
    tickets = generate_tickets(400)
    out_path = Path(__file__).parent / "raw_tickets.json"
    with open(out_path, "w") as f:
        json.dump(tickets, f, indent=2)
    print(f"Generated {len(tickets)} synthetic tickets -> {out_path}")
