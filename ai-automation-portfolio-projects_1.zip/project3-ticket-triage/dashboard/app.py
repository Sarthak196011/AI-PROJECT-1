import sys
import subprocess
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent / "src"))

import streamlit as st
import pandas as pd
from db import get_all_tickets, DB_PATH
from analytics import compute_resolution_hours, sla_compliance_report

st.set_page_config(page_title="Support Ticket Triage Dashboard", layout="wide")
st.title("🎫 AI-Powered Ticket Triage & Ops Analytics")
st.caption("Tickets auto-classified, prioritized, and routed by an LLM — tracked here for SLA and team-load analytics.")

# Auto-bootstrap on first load (e.g. a fresh Streamlit Cloud deploy with no DB yet)
ROOT = Path(__file__).parent.parent
if not DB_PATH.exists():
    with st.spinner("First run — generating sample tickets and running the pipeline..."):
        subprocess.run([sys.executable, str(ROOT / "data" / "generate_sample_tickets.py")], check=True, cwd=ROOT)
        subprocess.run([sys.executable, str(ROOT / "src" / "ingest.py")], check=True, cwd=ROOT / "src")
        subprocess.run([sys.executable, str(ROOT / "src" / "classify.py")], check=True, cwd=ROOT / "src")

tickets = get_all_tickets()
if not tickets:
    st.warning("No data yet. Run `python src/ingest.py` then `python src/classify.py` first.")
    st.stop()

df = pd.DataFrame(tickets)
df["created_at"] = pd.to_datetime(df["created_at"])
df["resolution_hours"] = df.apply(lambda r: compute_resolution_hours(r), axis=1)

col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Tickets", len(df))
col2.metric("Open Tickets", int(df["resolved_at"].isna().sum()))
col3.metric("P0 Tickets", int((df["priority"] == "P0").sum()))
col4.metric("Avg Resolution (hrs)", f"{df['resolution_hours'].mean():.1f}")

st.divider()

left, right = st.columns([2, 1])
with left:
    st.subheader("Ticket Volume Over Time")
    volume = df.groupby(df["created_at"].dt.date).size()
    st.line_chart(volume)

with right:
    st.subheader("Priority Distribution")
    st.bar_chart(df["priority"].value_counts().sort_index())

st.divider()

left2, right2 = st.columns(2)
with left2:
    st.subheader("Team Workload")
    st.bar_chart(df["assigned_team"].value_counts())

with right2:
    st.subheader("Avg Resolution Time by Category")
    avg_res = df.groupby("category")["resolution_hours"].mean().sort_values(ascending=False)
    st.bar_chart(avg_res)

st.divider()

st.subheader("SLA Compliance by Priority")
sla = sla_compliance_report()
sla_df = pd.DataFrame([
    {"Priority": p, "Resolved Count": s["count"],
     "SLA Compliance": f"{s['compliance_pct']:.1%}" if s["compliance_pct"] is not None else "N/A"}
    for p, s in sla.items()
])
st.dataframe(sla_df, use_container_width=True, hide_index=True)

st.divider()

st.subheader("Sentiment vs. Resolution Time")
st.caption("Insight: negative-sentiment tickets often correlate with longer resolution — useful for prioritizing escalations.")
sentiment_res = df.groupby("sentiment")["resolution_hours"].mean()
st.bar_chart(sentiment_res)

st.divider()

with st.expander("Explore all tickets"):
    priority_filter = st.multiselect("Filter by priority", options=sorted(df["priority"].dropna().unique().tolist()),
                                      default=sorted(df["priority"].dropna().unique().tolist()))
    filtered = df[df["priority"].isin(priority_filter)]
    st.dataframe(
        filtered[["ticket_id", "text", "category", "priority", "sentiment", "assigned_team", "created_at", "resolution_hours"]],
        use_container_width=True
    )
