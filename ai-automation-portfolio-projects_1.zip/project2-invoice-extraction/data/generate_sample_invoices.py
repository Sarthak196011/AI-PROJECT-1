"""
Generates synthetic invoice PDFs with varied formats/layouts (to prove the
extraction pipeline handles real-world inconsistency, not just one template).
Requires reportlab (pip install reportlab).
"""
import random
from pathlib import Path
from datetime import datetime, timedelta
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

OUT_DIR = Path(__file__).parent.parent / "sample_invoices"
OUT_DIR.mkdir(exist_ok=True)

VENDORS = ["Acme Cloud Services", "Northwind Office Supplies", "Globex IT Consulting",
           "Initech Software Licensing", "Umbrella Logistics", "Stark Materials Co.",
           "Wayne Facilities Mgmt", "Hooli Analytics Inc."]

ITEMS_BY_VENDOR = {
    "Acme Cloud Services": ["Compute hours", "Storage (GB)", "Data transfer"],
    "Northwind Office Supplies": ["Paper (case)", "Printer toner", "Desk chairs"],
    "Globex IT Consulting": ["Consulting hours", "Onsite support", "Training session"],
    "Initech Software Licensing": ["Annual license", "Support plan", "Add-on seats"],
    "Umbrella Logistics": ["Freight (per shipment)", "Warehousing", "Fuel surcharge"],
    "Stark Materials Co.": ["Steel (ton)", "Aluminum sheet", "Delivery fee"],
    "Wayne Facilities Mgmt": ["Cleaning service", "HVAC maintenance", "Security patrol"],
    "Hooli Analytics Inc.": ["API calls (1000s)", "Premium support", "Custom reports"],
}

def random_invoice(i, seed_vendor=None, inject_anomaly=False):
    vendor = seed_vendor or random.choice(VENDORS)
    items = random.sample(ITEMS_BY_VENDOR[vendor], k=random.randint(1, 3))
    line_items = []
    subtotal = 0
    for item in items:
        qty = random.randint(1, 20)
        unit_price = round(random.uniform(15, 500), 2)
        if inject_anomaly:
            unit_price *= random.uniform(4, 8)  # anomalously high charge
        amount = round(qty * unit_price, 2)
        subtotal += amount
        line_items.append((item, qty, unit_price, amount))

    tax = round(subtotal * 0.08, 2)
    total = round(subtotal + tax, 2)
    date = datetime.now() - timedelta(days=random.randint(0, 120))

    return {
        "invoice_id": f"INV-{2000 + i}",
        "vendor": vendor,
        "date": date.strftime("%Y-%m-%d"),
        "line_items": line_items,
        "subtotal": subtotal,
        "tax": tax,
        "total": total,
    }

def render_invoice_pdf(invoice, filepath, layout_variant=0):
    """Renders in one of a few different layouts to simulate real-world template variance."""
    c = canvas.Canvas(str(filepath), pagesize=letter)
    width, height = letter
    y = height - 72

    if layout_variant == 0:
        c.setFont("Helvetica-Bold", 16)
        c.drawString(72, y, invoice["vendor"])
        y -= 24
        c.setFont("Helvetica", 10)
        c.drawString(72, y, f"Invoice #: {invoice['invoice_id']}    Date: {invoice['date']}")
        y -= 30
    else:
        c.setFont("Helvetica-Bold", 14)
        c.drawString(72, y, f"INVOICE {invoice['invoice_id']}")
        y -= 20
        c.setFont("Helvetica", 10)
        c.drawString(72, y, f"Bill From: {invoice['vendor']}")
        y -= 14
        c.drawString(72, y, f"Date Issued: {invoice['date']}")
        y -= 30

    c.setFont("Helvetica-Bold", 10)
    c.drawString(72, y, "Description")
    c.drawString(300, y, "Qty")
    c.drawString(350, y, "Unit Price")
    c.drawString(450, y, "Amount")
    y -= 16
    c.setFont("Helvetica", 10)
    for item, qty, price, amount in invoice["line_items"]:
        c.drawString(72, y, item)
        c.drawString(300, y, str(qty))
        c.drawString(350, y, f"${price:,.2f}")
        c.drawString(450, y, f"${amount:,.2f}")
        y -= 16

    y -= 10
    c.line(72, y, 523, y)
    y -= 16
    c.drawString(400, y, f"Subtotal: ${invoice['subtotal']:,.2f}")
    y -= 14
    c.drawString(400, y, f"Tax: ${invoice['tax']:,.2f}")
    y -= 14
    c.setFont("Helvetica-Bold", 11)
    c.drawString(400, y, f"Total: ${invoice['total']:,.2f}")

    c.save()

def generate(n=25, seed=7):
    random.seed(seed)
    for i in range(n):
        inject_anomaly = (i == n - 1)  # last invoice is a deliberate anomaly for demo
        invoice = random_invoice(i, inject_anomaly=inject_anomaly)
        filepath = OUT_DIR / f"{invoice['invoice_id']}.pdf"
        render_invoice_pdf(invoice, filepath, layout_variant=i % 2)
    print(f"Generated {n} synthetic invoice PDFs -> {OUT_DIR}")

if __name__ == "__main__":
    generate(25)
