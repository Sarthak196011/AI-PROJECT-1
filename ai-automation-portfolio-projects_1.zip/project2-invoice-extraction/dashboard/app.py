import sys
import subprocess
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent / "src"))

import streamlit as st
import pandas as pd
from db import get_all_invoices, DB_PATH

st.set_page_config(page_title="Invoice Intelligence Dashboard", layout="wide")
st.title("🧾 Invoice Extraction & Spend Analytics")
st.caption("PDF invoices → LLM-structured data → validated → analyzed for spend trends and anomalies.")

# Auto-bootstrap on first load (e.g. a fresh Streamlit Cloud deploy with no DB yet)
ROOT = Path(__file__).parent.parent
if not DB_PATH.exists():
    with st.spinner("First run — generating sample invoices and running the pipeline..."):
        subprocess.run([sys.executable, str(ROOT / "data" / "generate_sample_invoices.py")], check=True, cwd=ROOT)
        subprocess.run([sys.executable, str(ROOT / "src" / "pipeline.py")], check=True, cwd=ROOT / "src")

invoices = get_all_invoices()
if not invoices:
    st.warning("No data yet. Run `python src/pipeline.py` first (after generating sample invoices).")
    st.stop()

df = pd.DataFrame(invoices)
df["invoice_date"] = pd.to_datetime(df["invoice_date"], errors="coerce")

col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Invoices", len(df))
col2.metric("Total Spend", f"${df['total'].sum():,.0f}")
col3.metric("Flagged for Review", int(df["flagged_for_review"].sum()))
col4.metric("Unique Vendors", df["vendor"].nunique())

st.divider()

left, right = st.columns([2, 1])
with left:
    st.subheader("Monthly Spend Trend")
    monthly = df.dropna(subset=["invoice_date"]).groupby(df["invoice_date"].dt.to_period("M"))["total"].sum()
    monthly.index = monthly.index.astype(str)
    st.bar_chart(monthly)

with right:
    st.subheader("Spend by Vendor")
    vendor_spend = df.groupby("vendor")["total"].sum().sort_values(ascending=False)
    st.bar_chart(vendor_spend)

st.divider()

st.subheader("⚠️ Flagged Invoices (Validation Issues)")
flagged = df[df["flagged_for_review"] == 1][["invoice_id", "vendor", "invoice_date", "total", "flag_reason", "source_file"]]
if flagged.empty:
    st.info("No invoices currently flagged.")
else:
    st.dataframe(flagged, use_container_width=True)

st.divider()

with st.expander("All processed invoices"):
    st.dataframe(
        df[["invoice_id", "vendor", "invoice_date", "subtotal", "tax", "total", "flagged_for_review", "source_file"]],
        use_container_width=True
    )
