import sqlite3
import json
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "invoices.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS invoices (
    invoice_id TEXT PRIMARY KEY,
    vendor TEXT,
    invoice_date TEXT,
    line_items TEXT,     -- JSON
    subtotal REAL,
    tax REAL,
    total REAL,
    source_file TEXT,
    flagged_for_review INTEGER DEFAULT 0,
    flag_reason TEXT,
    processed_at TEXT
);
"""

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    conn.execute(SCHEMA)
    conn.commit()
    conn.close()

def upsert_invoice(record: dict):
    conn = get_connection()
    conn.execute("""
        INSERT INTO invoices (invoice_id, vendor, invoice_date, line_items, subtotal, tax, total,
                               source_file, flagged_for_review, flag_reason, processed_at)
        VALUES (:invoice_id, :vendor, :invoice_date, :line_items, :subtotal, :tax, :total,
                :source_file, :flagged_for_review, :flag_reason, :processed_at)
        ON CONFLICT(invoice_id) DO UPDATE SET
            vendor=excluded.vendor, invoice_date=excluded.invoice_date,
            line_items=excluded.line_items, subtotal=excluded.subtotal,
            tax=excluded.tax, total=excluded.total, source_file=excluded.source_file,
            flagged_for_review=excluded.flagged_for_review, flag_reason=excluded.flag_reason,
            processed_at=excluded.processed_at
    """, record)
    conn.commit()
    conn.close()

def get_all_invoices():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM invoices ORDER BY invoice_date DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]
