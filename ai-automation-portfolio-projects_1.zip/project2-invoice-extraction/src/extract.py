"""
Extracts raw text from invoice PDFs. Uses pdfplumber for text-based PDFs.
For scanned/image invoices, fall back to OCR (pytesseract) — see extract_with_ocr().
"""
import pdfplumber
from pathlib import Path

INVOICE_DIR = Path(__file__).parent.parent / "sample_invoices"

def extract_text_from_pdf(filepath: Path) -> str:
    text_parts = []
    with pdfplumber.open(filepath) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            text_parts.append(page_text)
    return "\n".join(text_parts)

def extract_with_ocr(filepath: Path) -> str:
    """Fallback for scanned invoices with no extractable text layer."""
    import pytesseract
    from pdf2image import convert_from_path
    images = convert_from_path(str(filepath))
    return "\n".join(pytesseract.image_to_string(img) for img in images)

def extract_all():
    results = {}
    for pdf_file in sorted(INVOICE_DIR.glob("*.pdf")):
        text = extract_text_from_pdf(pdf_file)
        if not text.strip():
            print(f"  No text layer found in {pdf_file.name}, falling back to OCR...")
            text = extract_with_ocr(pdf_file)
        results[pdf_file.name] = text
    return results

if __name__ == "__main__":
    all_text = extract_all()
    print(f"Extracted text from {len(all_text)} invoices.")
    sample_key = next(iter(all_text))
    print(f"\n--- Sample extraction ({sample_key}) ---\n{all_text[sample_key][:400]}")
