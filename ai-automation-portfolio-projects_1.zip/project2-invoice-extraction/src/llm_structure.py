"""
Converts raw invoice text (which varies in layout/format) into a strict
structured JSON schema using Claude — this is what handles the messy
formatting variance far better than brittle regex would.
Falls back to a regex-based mock structurer if no ANTHROPIC_API_KEY is set,
so the pipeline is fully demoable without an API key.
"""
import os
import re
import json

USE_LIVE_API = bool(os.environ.get("ANTHROPIC_API_KEY"))

STRUCTURE_PROMPT = """Extract structured invoice data from the raw text below.
The layout may vary — find the fields regardless of position/formatting.

Raw invoice text:
---
{text}
---

Respond with ONLY valid JSON, no other text, in this exact schema:
{{
  "invoice_id": "string",
  "vendor": "string",
  "invoice_date": "YYYY-MM-DD",
  "line_items": [{{"description": "string", "qty": number, "unit_price": number, "amount": number}}],
  "subtotal": number,
  "tax": number,
  "total": number
}}
"""

def structure_with_claude(text: str) -> dict:
    import anthropic
    client = anthropic.Anthropic()
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=800,
        messages=[{"role": "user", "content": STRUCTURE_PROMPT.format(text=text)}]
    )
    raw = response.content[0].text.strip()
    raw = re.sub(r"^```json|```$", "", raw, flags=re.MULTILINE).strip()
    return json.loads(raw)

def structure_with_regex(text: str) -> dict:
    """Regex-based mock structurer — stands in for the LLM for zero-setup demoing.
    Works against the layouts produced by generate_sample_invoices.py."""

    invoice_id = re.search(r"(INV-\d+)", text)
    date = re.search(r"(?:Date(?: Issued)?:?)\s*([\d-]{8,10})", text)

    # vendor: first line for layout 0, "Bill From:" line for layout 1
    vendor_match = re.search(r"Bill From:\s*(.+)", text)
    if vendor_match:
        vendor = vendor_match.group(1).strip()
    else:
        first_line = text.strip().split("\n")[0]
        vendor = re.sub(r"INVOICE\s*INV-\d+", "", first_line).strip() or first_line

    line_items = []
    for match in re.finditer(
        r"^(?!Description)([A-Za-z][\w\s()]+?)\s+(\d+)\s+\$([\d,.]+)\s+\$([\d,.]+)$",
        text, re.MULTILINE
    ):
        desc, qty, price, amount = match.groups()
        line_items.append({
            "description": desc.strip(),
            "qty": int(qty),
            "unit_price": float(price.replace(",", "")),
            "amount": float(amount.replace(",", "")),
        })

    subtotal = re.search(r"Subtotal:\s*\$([\d,.]+)", text)
    tax = re.search(r"Tax:\s*\$([\d,.]+)", text)
    total = re.search(r"Total:\s*\$([\d,.]+)", text)

    return {
        "invoice_id": invoice_id.group(1) if invoice_id else "UNKNOWN",
        "vendor": vendor,
        "invoice_date": date.group(1) if date else "UNKNOWN",
        "line_items": line_items,
        "subtotal": float(subtotal.group(1).replace(",", "")) if subtotal else 0.0,
        "tax": float(tax.group(1).replace(",", "")) if tax else 0.0,
        "total": float(total.group(1).replace(",", "")) if total else 0.0,
    }

def structure_invoice(text: str) -> dict:
    if USE_LIVE_API:
        try:
            return structure_with_claude(text)
        except Exception as e:
            print(f"  ! Claude structuring failed ({e}), falling back to regex")
    return structure_with_regex(text)
