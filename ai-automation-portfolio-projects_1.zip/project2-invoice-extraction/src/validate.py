"""
Rule-based validation layer — this is the key "don't blindly trust the LLM"
step that a data analyst brings to a document-AI pipeline. Flags:
  - arithmetic mismatches (line items don't sum to subtotal/total)
  - missing/unparseable fields
  - amounts anomalously high vs. that vendor's historical average
"""

def validate_arithmetic(invoice: dict, tolerance=0.02) -> list:
    issues = []
    computed_subtotal = sum(li["amount"] for li in invoice.get("line_items", []))
    if invoice.get("subtotal") and abs(computed_subtotal - invoice["subtotal"]) > tolerance * max(computed_subtotal, 1):
        issues.append(f"Line items sum ({computed_subtotal:.2f}) doesn't match subtotal ({invoice['subtotal']:.2f})")

    expected_total = (invoice.get("subtotal") or 0) + (invoice.get("tax") or 0)
    if invoice.get("total") and abs(expected_total - invoice["total"]) > tolerance * max(expected_total, 1):
        issues.append(f"Subtotal + tax ({expected_total:.2f}) doesn't match total ({invoice['total']:.2f})")

    return issues

def validate_completeness(invoice: dict) -> list:
    issues = []
    for field in ["invoice_id", "vendor", "invoice_date", "total"]:
        val = invoice.get(field)
        if val in (None, "", "UNKNOWN", 0):
            issues.append(f"Missing or unparseable field: {field}")
    if not invoice.get("line_items"):
        issues.append("No line items extracted")
    return issues

def validate_anomaly(invoice: dict, vendor_history_avg: dict) -> list:
    """vendor_history_avg: {vendor_name: average_total} computed from prior invoices."""
    issues = []
    vendor = invoice.get("vendor")
    avg = vendor_history_avg.get(vendor)
    if avg and invoice.get("total") and invoice["total"] > 3 * avg:
        issues.append(f"Total (${invoice['total']:.2f}) is {invoice['total']/avg:.1f}x this vendor's historical average (${avg:.2f})")
    return issues

def run_all_validations(invoice: dict, vendor_history_avg: dict) -> tuple:
    """Returns (is_flagged: bool, reasons: list[str])"""
    issues = []
    issues += validate_completeness(invoice)
    issues += validate_arithmetic(invoice)
    issues += validate_anomaly(invoice, vendor_history_avg)
    return (len(issues) > 0, issues)
