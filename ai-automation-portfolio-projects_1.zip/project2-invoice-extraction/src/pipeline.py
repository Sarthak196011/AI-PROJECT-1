"""
Orchestrates the full invoice pipeline: extract -> structure -> validate -> store.
Run this after generating sample invoices (data/generate_sample_invoices.py).
"""
import json
from datetime import datetime
from pathlib import Path

from extract import extract_all
from llm_structure import structure_invoice, USE_LIVE_API
from validate import run_all_validations
from db import init_db, upsert_invoice, get_all_invoices

def compute_vendor_history_avg():
    """Uses whatever is already in the DB as the historical baseline for anomaly checks."""
    existing = get_all_invoices()
    totals_by_vendor = {}
    for inv in existing:
        totals_by_vendor.setdefault(inv["vendor"], []).append(inv["total"])
    return {v: sum(t) / len(t) for v, t in totals_by_vendor.items() if t}

def run_pipeline():
    init_db()
    mode = "Claude API" if USE_LIVE_API else "regex mock structurer (set ANTHROPIC_API_KEY for live LLM)"
    print(f"Running pipeline using {mode}...\n")

    raw_texts = extract_all()
    vendor_avg = compute_vendor_history_avg()

    for filename, text in raw_texts.items():
        structured = structure_invoice(text)
        flagged, reasons = run_all_validations(structured, vendor_avg)

        record = {
            "invoice_id": structured["invoice_id"],
            "vendor": structured["vendor"],
            "invoice_date": structured["invoice_date"],
            "line_items": json.dumps(structured["line_items"]),
            "subtotal": structured["subtotal"],
            "tax": structured["tax"],
            "total": structured["total"],
            "source_file": filename,
            "flagged_for_review": int(flagged),
            "flag_reason": "; ".join(reasons) if reasons else None,
            "processed_at": datetime.now().isoformat(),
        }
        upsert_invoice(record)

        # update running vendor average as we go so the anomaly check has more history over time
        vendor_avg.setdefault(structured["vendor"], structured["total"])

        status = f"⚠️  FLAGGED ({len(reasons)} issues)" if flagged else "✓ OK"
        print(f"{filename:20s} -> {structured['invoice_id']:12s} {structured['vendor']:28s} ${structured['total']:>10,.2f}  {status}")

    print(f"\nProcessed {len(raw_texts)} invoices.")

if __name__ == "__main__":
    run_pipeline()
