# 🧾 Invoice Auto-Extraction & Spend Analysis Tool

Extracts structured data from unstructured invoice PDFs (varied layouts), validates it against business rules, flags anomalies, and analyzes spend trends — a document-AI pipeline that doesn't blindly trust the LLM.

## Problem
Finance/ops teams manually key in invoice data from PDFs with inconsistent formats, which is slow and error-prone. Anomalous or duplicate charges often go unnoticed until an audit.

## Solution
A pipeline that extracts text from any invoice layout, uses an LLM to normalize it into a strict schema, runs rule-based validation (arithmetic checks, completeness, vendor-spend anomaly detection), and surfaces everything in a spend-analytics dashboard.

## Architecture

```mermaid
flowchart LR
    A[Invoice PDFs] --> B[Text Extraction<br/>pdfplumber + OCR fallback]
    B --> C[LLM Structuring<br/>strict JSON schema]
    C --> D[Validation Layer<br/>arithmetic + completeness + anomaly checks]
    D --> E[(SQLite / Postgres)]
    E --> F[Streamlit Dashboard<br/>spend trends, flagged invoices]
```

## Why the Validation Layer Matters
This is the part that separates a "data analyst" project from a pure LLM demo: the pipeline doesn't trust extracted numbers blindly. It checks that line items sum to the subtotal, that subtotal + tax = total, that no required field came back empty, and flags any invoice whose total is 3x+ a vendor's historical average — a lightweight anomaly detector built entirely from the data itself.

## Tech Stack
- **Python** — pipeline orchestration
- **pdfplumber** — text-based PDF extraction (+ pytesseract/pdf2image OCR fallback for scanned docs)
- **Claude API** (structured JSON output) — normalizing inconsistent invoice layouts into one schema
- **reportlab** — generates synthetic multi-layout sample invoices for testing
- **SQLite** (swap for Postgres in production) — storage
- **Streamlit** — spend analytics dashboard

## How to Run

```bash
pip install -r requirements.txt

# 1. Generate synthetic sample invoices (2 different layouts, one deliberate anomaly)
python data/generate_sample_invoices.py

# 2. Run the full pipeline: extract -> structure -> validate -> store
#    Runs in mock mode with zero setup; set ANTHROPIC_API_KEY in .env for live LLM structuring
python src/pipeline.py

# 3. Launch the dashboard
streamlit run dashboard/app.py
```

## What the Dashboard Shows
- Total spend, invoice count, vendor count, flagged-invoice count
- Monthly spend trend
- Spend by vendor
- Table of flagged invoices with the specific validation reason (e.g., "Total is 5.2x vendor's historical average")
- Full invoice explorer

## Production Notes / What I'd Improve
- Add duplicate-invoice detection (same vendor + amount + date within a window)
- Persist vendor historical averages across runs instead of recomputing per session
- Add a human-in-the-loop review UI for flagged invoices (approve/correct → feeds back into the DB)
- Batch LLM calls instead of one-per-invoice to cut latency/cost at scale
- Add confidence scores from the LLM extraction to prioritize which flagged invoices need review first

## Sample Impact (based on synthetic data)
Out of 25 synthetic invoices across 2 layout variants, the pipeline correctly extracted structured data across both formats and automatically flagged the deliberately-injected anomalous invoice (5x+ a vendor's historical average) without any manual review.
