# 📊 Automated Customer Feedback Intelligence Pipeline

An end-to-end pipeline that ingests customer reviews, uses an LLM to classify sentiment/themes/urgency, stores structured results, and surfaces insights via a live dashboard with automated spike alerting.

## Problem
Product and support teams drown in unstructured feedback. Critical issues (churn risk, bugs, data loss complaints) get buried in the noise until it's too late to act on them.

## Solution
A scheduled pipeline that automatically classifies every incoming review, tracks sentiment trends, and alerts the team the moment negative sentiment spikes — instead of relying on someone manually reading reviews.

## Architecture

```mermaid
flowchart LR
    A[Review Source<br/>Play Store / App Store / Twitter] -->|scheduled pull| B[Ingest Script]
    B --> C[(SQLite / Postgres)]
    C --> D[LLM Classification<br/>sentiment, themes, urgency]
    D --> C
    C --> E[Alert Check<br/>negative spike detection]
    E -->|threshold breached| F[Slack / Email Alert]
    C --> G[Streamlit Dashboard]
```

## Tech Stack
- **Python** — pipeline orchestration
- **Claude API** (structured JSON output) — sentiment/theme/urgency classification
- **SQLite** (swap for Postgres in production) — storage
- **Streamlit** — dashboard
- **Slack Webhooks** — automated alerting

## How to Run

```bash
pip install -r requirements.txt

# 1. Generate synthetic sample data (or plug in a real scraper here)
cd data && python generate_sample_data.py && cd ..

# 2. Ingest into the database
python src/ingest.py

# 3. Classify with the LLM (runs in mock mode with zero setup;
#    set ANTHROPIC_API_KEY in a .env file for live classification)
python src/llm_classify.py

# 4. Check for sentiment spikes (mock alert without SLACK_WEBHOOK_URL)
python src/alert.py

# 5. Launch the dashboard
streamlit run dashboard/app.py
```

**Zero-setup demo mode:** the classifier and alerter both fall back to lightweight heuristics if no API key / webhook is configured, so the entire pipeline is runnable and demoable out of the box. Flip to live mode by adding a `.env` (see `.env.example`).

## What the Dashboard Shows
- Sentiment trend over time
- Sentiment breakdown
- Top complaint/discussion themes
- Table of critical/urgent reviews needing attention
- Full searchable/filterable review explorer

## Production Notes / What I'd Improve
- Replace SQLite with Postgres + a managed scheduler (Airflow / AWS EventBridge) for real cron reliability
- Add deduplication + incremental ingestion (only classify new reviews since last run)
- Add a feedback loop where human corrections to LLM classifications are logged and used for prompt refinement
- Add cost tracking for LLM API calls at scale (batch classification instead of one-by-one)

## Sample Impact (based on synthetic data)
Automated triage flagged critical/churn-risk reviews within the same run they arrived, versus a typical manual review cadence of days — and surfaced a synthetic billing-complaint spike in the dashboard's alerting logic before it would have been caught by manual spot-checking.
