"""
Checks recent negative-sentiment rate against the trailing baseline and
fires a Slack webhook alert if it spikes. This is the "automation" trigger
that would run on a schedule (cron/APScheduler) alongside ingest + classify.
"""
import os
import json
import requests
from datetime import datetime, timedelta
from db import get_all_reviews

SLACK_WEBHOOK_URL = os.environ.get("SLACK_WEBHOOK_URL")  # set in .env
SPIKE_THRESHOLD_MULTIPLIER = 1.5  # alert if recent negative rate is 1.5x the baseline

def check_for_spike(recent_days=3, baseline_days=14):
    reviews = get_all_reviews()
    now = datetime.now()

    def negative_rate(reviews_subset):
        if not reviews_subset:
            return 0
        neg = sum(1 for r in reviews_subset if r["sentiment"] == "negative")
        return neg / len(reviews_subset)

    recent = [r for r in reviews if r["date"] and
              datetime.fromisoformat(r["date"]) > now - timedelta(days=recent_days)]
    baseline = [r for r in reviews if r["date"] and
                now - timedelta(days=baseline_days) < datetime.fromisoformat(r["date"]) <= now - timedelta(days=recent_days)]

    recent_rate = negative_rate(recent)
    baseline_rate = negative_rate(baseline) or 0.01  # avoid div by zero

    ratio = recent_rate / baseline_rate

    print(f"Recent negative rate ({recent_days}d): {recent_rate:.1%}")
    print(f"Baseline negative rate ({baseline_days}d prior): {baseline_rate:.1%}")
    print(f"Ratio: {ratio:.2f}x")

    if ratio >= SPIKE_THRESHOLD_MULTIPLIER:
        message = (
            f":rotating_light: *Negative feedback spike detected*\n"
            f"Recent negative rate ({recent_days}d): {recent_rate:.1%} "
            f"vs baseline {baseline_rate:.1%} ({ratio:.1f}x increase)\n"
            f"{len(recent)} reviews in the recent window."
        )
        send_alert(message)
        return True
    return False

def send_alert(message: str):
    if SLACK_WEBHOOK_URL:
        requests.post(SLACK_WEBHOOK_URL, json={"text": message})
        print("Alert sent to Slack.")
    else:
        print("[MOCK ALERT — set SLACK_WEBHOOK_URL to send for real]")
        print(message)

if __name__ == "__main__":
    check_for_spike()
