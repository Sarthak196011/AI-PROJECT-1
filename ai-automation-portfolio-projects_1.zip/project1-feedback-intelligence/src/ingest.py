"""
Loads raw review data into the database.
In production, replace load_from_json() with a call to google-play-scraper,
an app-store RSS feed, or a Twitter/X API pull, scheduled via cron/APScheduler.
"""
import json
from pathlib import Path
from db import init_db, insert_raw_review

RAW_DATA_PATH = Path(__file__).parent.parent / "data" / "raw_reviews.json"

def load_from_json():
    with open(RAW_DATA_PATH) as f:
        reviews = json.load(f)

    init_db()
    for review in reviews:
        insert_raw_review(review)

    print(f"Ingested {len(reviews)} reviews into database.")

if __name__ == "__main__":
    load_from_json()
