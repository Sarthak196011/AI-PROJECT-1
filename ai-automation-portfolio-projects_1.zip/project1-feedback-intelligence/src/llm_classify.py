"""
Classifies each unprocessed review using Claude's structured JSON output.
Falls back to a lightweight keyword-based mock classifier if no ANTHROPIC_API_KEY
is set, so the whole pipeline is runnable/demoable without an API key.
"""
import os
import json
import re
from datetime import datetime
from db import get_unprocessed_reviews, update_with_classification

USE_LIVE_API = bool(os.environ.get("ANTHROPIC_API_KEY"))

CLASSIFY_PROMPT = """You are a customer feedback analyst. Classify the following app review.

Review: "{text}"

Respond with ONLY valid JSON, no other text, in this exact schema:
{{
  "sentiment": "positive" | "negative" | "neutral",
  "themes": ["theme1", "theme2"],   // short tags e.g. "pricing", "bugs", "UX", "support"
  "urgency": "low" | "medium" | "critical"  // critical = churn risk, data loss, major bug
}}
"""

def classify_with_claude(text: str) -> dict:
    import anthropic
    client = anthropic.Anthropic()
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=200,
        messages=[{"role": "user", "content": CLASSIFY_PROMPT.format(text=text)}]
    )
    raw = response.content[0].text.strip()
    raw = re.sub(r"^```json|```$", "", raw, flags=re.MULTILINE).strip()
    return json.loads(raw)

def classify_with_mock(text: str) -> dict:
    """Simple keyword heuristic — stands in for the LLM so the project runs with zero API cost/setup."""
    lower = text.lower()
    negative_kw = ["crash", "frustrat", "broken", "expensive", "cancel", "slow",
                   "lost my data", "terrible", "never responded", "switch"]
    positive_kw = ["love", "great", "perfectly", "game changer", "best", "fast when"]
    critical_kw = ["crash", "lost my data", "cancel", "switch"]

    if any(k in lower for k in critical_kw):
        urgency = "critical"
    elif any(k in lower for k in negative_kw):
        urgency = "medium"
    else:
        urgency = "low"

    if any(k in lower for k in negative_kw):
        sentiment = "negative"
    elif any(k in lower for k in positive_kw):
        sentiment = "positive"
    else:
        sentiment = "neutral"

    themes = []
    theme_map = {
        "billing": ["billing", "expensive", "subscription", "pricing"],
        "bugs": ["crash", "broken", "bug"],
        "support": ["support"],
        "performance": ["slow"],
        "data": ["lost my data", "sync"],
    }
    for theme, kws in theme_map.items():
        if any(kw in lower for kw in kws):
            themes.append(theme)
    if not themes:
        themes = ["general"]

    return {"sentiment": sentiment, "themes": themes, "urgency": urgency}

def run_classification_batch():
    reviews = get_unprocessed_reviews()
    if not reviews:
        print("No unprocessed reviews found.")
        return

    classifier = classify_with_claude if USE_LIVE_API else classify_with_mock
    mode = "Claude API" if USE_LIVE_API else "mock heuristic (set ANTHROPIC_API_KEY to use live LLM)"
    print(f"Classifying {len(reviews)} reviews using {mode}...")

    for review in reviews:
        try:
            result = classifier(review["text"])
        except Exception as e:
            print(f"  ! Failed on {review['review_id']}: {e} — falling back to mock")
            result = classify_with_mock(review["text"])

        update_with_classification(
            review_id=review["review_id"],
            sentiment=result["sentiment"],
            themes=result["themes"],
            urgency=result["urgency"],
            processed_at=datetime.now().isoformat()
        )

    print(f"Done. Classified {len(reviews)} reviews.")

if __name__ == "__main__":
    run_classification_batch()
