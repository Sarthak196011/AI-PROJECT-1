"""SQLite storage layer. Swap for Postgres in production by changing the connection string."""
import sqlite3
import json
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "feedback.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS reviews (
    review_id TEXT PRIMARY KEY,
    text TEXT NOT NULL,
    rating INTEGER,
    date TEXT NOT NULL,
    sentiment TEXT,
    themes TEXT,       -- JSON list stored as text
    urgency TEXT,       -- low / medium / critical
    processed_at TEXT
);
"""

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    conn.execute(SCHEMA)
    conn.commit()
    conn.close()

def insert_raw_review(review: dict):
    conn = get_connection()
    conn.execute(
        "INSERT OR IGNORE INTO reviews (review_id, text, rating, date) VALUES (?, ?, ?, ?)",
        (review["review_id"], review["text"], review["rating"], review["date"])
    )
    conn.commit()
    conn.close()

def update_with_classification(review_id: str, sentiment: str, themes: list, urgency: str, processed_at: str):
    conn = get_connection()
    conn.execute(
        "UPDATE reviews SET sentiment = ?, themes = ?, urgency = ?, processed_at = ? WHERE review_id = ?",
        (sentiment, json.dumps(themes), urgency, processed_at, review_id)
    )
    conn.commit()
    conn.close()

def get_unprocessed_reviews():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM reviews WHERE sentiment IS NULL").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_all_reviews():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM reviews ORDER BY date DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]
