"""
Generates a realistic synthetic dataset of app reviews for the pipeline to process.
Run this first if you don't want to scrape live data (e.g., google-play-scraper).
"""
import json
import random
from datetime import datetime, timedelta

POSITIVE_TEMPLATES = [
    "Love this app, the {feature} works perfectly!",
    "Been using it for months, {feature} is a game changer.",
    "Great {feature}, super intuitive and fast.",
    "Best app in its category, especially the {feature}.",
    "Customer support was fast when I had an issue with {feature}.",
]

NEGATIVE_TEMPLATES = [
    "The {feature} keeps crashing on my phone, very frustrating.",
    "Been waiting 3 days for a fix on {feature}, still broken.",
    "Way too expensive for what it offers, cancelling my subscription.",
    "The {feature} is so slow, unusable during peak hours.",
    "Lost my data after the last update, terrible experience with {feature}.",
    "Support never responded about my {feature} issue, thinking of switching.",
]

NEUTRAL_TEMPLATES = [
    "It's okay, {feature} could be better.",
    "Does what it says, nothing special about {feature}.",
    "Would like to see more customization in {feature}.",
    "Average experience, {feature} needs some polish.",
]

FEATURES = ["checkout flow", "search", "notifications", "login", "dashboard",
            "billing", "sync feature", "customer support", "mobile app", "pricing"]

def generate_reviews(n=500, seed=42):
    random.seed(seed)
    reviews = []
    start_date = datetime.now() - timedelta(days=60)

    for i in range(n):
        sentiment_roll = random.random()
        feature = random.choice(FEATURES)

        if sentiment_roll < 0.35:
            template = random.choice(NEGATIVE_TEMPLATES)
            true_sentiment = "negative"
        elif sentiment_roll < 0.55:
            template = random.choice(NEUTRAL_TEMPLATES)
            true_sentiment = "neutral"
        else:
            template = random.choice(POSITIVE_TEMPLATES)
            true_sentiment = "positive"

        text = template.format(feature=feature)
        date = start_date + timedelta(
            days=random.randint(0, 60),
            hours=random.randint(0, 23)
        )

        # Inject a spike of negative reviews in the last 3 days to demo alerting
        if i > n - 25 and random.random() < 0.7:
            template = random.choice(NEGATIVE_TEMPLATES)
            text = template.format(feature="billing")
            true_sentiment = "negative"
            date = datetime.now() - timedelta(hours=random.randint(0, 72))

        reviews.append({
            "review_id": f"rev_{i:04d}",
            "text": text,
            "rating": {"positive": random.choice([4, 5]),
                       "neutral": 3,
                       "negative": random.choice([1, 2])}[true_sentiment],
            "date": date.isoformat(),
            "_true_sentiment_for_eval": true_sentiment  # not used by pipeline, just for validation
        })

    return reviews

if __name__ == "__main__":
    from pathlib import Path
    reviews = generate_reviews(500)
    out_path = Path(__file__).parent / "raw_reviews.json"
    with open(out_path, "w") as f:
        json.dump(reviews, f, indent=2)
    print(f"Generated {len(reviews)} synthetic reviews -> {out_path}")
