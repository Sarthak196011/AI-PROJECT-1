import sys
import subprocess
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent / "src"))

import streamlit as st
import pandas as pd
import json
from db import get_all_reviews, DB_PATH

st.set_page_config(page_title="Feedback Intelligence Dashboard", layout="wide")
st.title("📊 Customer Feedback Intelligence")
st.caption("Automated sentiment classification, theme extraction, and urgency triage — powered by an LLM pipeline.")

# Auto-bootstrap on first load (e.g. a fresh Streamlit Cloud deploy with no DB yet)
ROOT = Path(__file__).parent.parent
if not DB_PATH.exists():
    with st.spinner("First run — generating sample data and running the pipeline..."):
        subprocess.run([sys.executable, str(ROOT / "data" / "generate_sample_data.py")], check=True, cwd=ROOT)
        subprocess.run([sys.executable, str(ROOT / "src" / "ingest.py")], check=True, cwd=ROOT / "src")
        subprocess.run([sys.executable, str(ROOT / "src" / "llm_classify.py")], check=True, cwd=ROOT / "src")

reviews = get_all_reviews()
if not reviews:
    st.warning("No data yet. Run `python src/ingest.py` then `python src/llm_classify.py` first.")
    st.stop()

df = pd.DataFrame(reviews)
df["date"] = pd.to_datetime(df["date"])
df["themes_list"] = df["themes"].apply(lambda x: json.loads(x) if x else [])

# --- Top metrics ---
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Reviews", len(df))
col2.metric("Negative %", f"{(df['sentiment'] == 'negative').mean():.1%}")
col3.metric("Critical Flags", int((df["urgency"] == "critical").sum()))
col4.metric("Avg Rating", f"{df['rating'].mean():.2f} ★")

st.divider()

# --- Sentiment trend over time ---
left, right = st.columns([2, 1])
with left:
    st.subheader("Sentiment Trend Over Time")
    trend = df.groupby([df["date"].dt.date, "sentiment"]).size().unstack(fill_value=0)
    st.line_chart(trend)

with right:
    st.subheader("Sentiment Breakdown")
    st.bar_chart(df["sentiment"].value_counts())

st.divider()

# --- Themes ---
st.subheader("Top Complaint / Discussion Themes")
all_themes = df["themes_list"].explode()
theme_counts = all_themes.value_counts().head(10)
st.bar_chart(theme_counts)

st.divider()

# --- Urgent flags table ---
st.subheader("🚨 Urgent / Critical Reviews Needing Attention")
critical = df[df["urgency"] == "critical"][["review_id", "text", "date", "themes_list"]]
if critical.empty:
    st.info("No critical reviews currently flagged.")
else:
    st.dataframe(critical, use_container_width=True)

st.divider()

# --- Raw explorer ---
with st.expander("Explore all reviews"):
    sentiment_filter = st.multiselect("Filter by sentiment", options=df["sentiment"].unique().tolist(),
                                       default=df["sentiment"].unique().tolist())
    filtered = df[df["sentiment"].isin(sentiment_filter)]
    st.dataframe(filtered[["review_id", "text", "sentiment", "urgency", "themes_list", "date"]],
                 use_container_width=True)
