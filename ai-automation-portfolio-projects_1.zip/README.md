# AI Automation + Data Analyst Portfolio Projects

Three end-to-end projects, each combining LLM-powered automation with real data analytics — built to demonstrate the overlap between AI engineering and data analyst skill sets.

| Project | What it shows | Folder |
|---|---|---|
| 📊 **Customer Feedback Intelligence Pipeline** | NLP classification, scheduled automation, spike alerting, dashboarding | `project1-feedback-intelligence/` |
| 🧾 **Invoice Auto-Extraction & Spend Analysis** | Document AI, data validation, anomaly detection, spend analytics | `project2-invoice-extraction/` |
| 🎫 **AI-Powered Ticket Triage & Ops Analytics** | Few-shot classification, workflow routing, SLA analytics | `project3-ticket-triage/` |

## Quick Start (any project)

Each project is fully self-contained and runs in **zero-setup mock mode** — no API key required to see it working end-to-end. See each project's own `README.md` for exact commands, but the pattern is:

```bash
cd project-folder/
pip install -r requirements.txt
python data/generate_sample_*.py    # create synthetic sample data
python src/<pipeline-step-1>.py     # ingest / extract
python src/<pipeline-step-2>.py     # LLM classify / structure
streamlit run dashboard/app.py      # view results
```

To switch any project from mock mode to live LLM calls, copy `.env.example` to `.env` and add your `ANTHROPIC_API_KEY` (get one at [console.anthropic.com](https://console.anthropic.com)).

## Why These Three
All three follow the same underlying pattern that shows up constantly in real ops/data roles:

**Unstructured input → LLM structuring/classification → validation/rules → storage → analytics dashboard → automated alert**

That pattern is the core of "AI automation + data analysis" work at most companies — whether it's applied to reviews, documents, or support tickets. Building all three signals that you can apply the same architecture to different domains, not that you memorized one tutorial.

## Suggested Next Steps for Each
- Deploy the dashboards for free on [Streamlit Community Cloud](https://streamlit.io/cloud) so they're clickable, not just code
- Record a 60–90 second Loom walkthrough for each project's README
- Add a short "Impact" section with real or estimated numbers (time saved, issues caught, accuracy vs. manual baseline)
- Push each as a separate GitHub repo (or one repo with clear subfolders, as here) with a pinned pin on your profile
